import pandas as pd

# ✅ 1. Зареждане на данните
df = pd.read_csv("user_ratings.csv")

# 🚿 2. Почистване и стандартизиране на колоните
df.columns = df.columns.str.strip().str.lower().str.replace(" ", "_").str.replace(r'[^\w]', '', regex=True)

for col in ["product_id", "rating", "user_id"]:
    if col not in df.columns:
        df[col] = None  # или някаква стойност по подразбиране

# 📋 🔍 3. Принтирай колоните (тук го слагаш)
print("📋 Колони в df:", df.columns.tolist())

# 🛡️ 4. Проверка за задължителни колони
required_columns = ["product_id", "rating", "user_id"]
missing = [col for col in required_columns if col not in df.columns]
if missing:
    print(f"⚠️ Липсват следните колони: {missing}")
    exit()

# 📊 5. Средна оценка по продукт
product_avg = df.groupby("product_id")["rating"].mean().sort_values(ascending=False)

# 🙋‍♂️ 6. Активност на потребителите
user_activity = df.groupby("user_id").size().sort_values(ascending=False)

# ⭐ 7. Продукти с рейтинг ≥ 4
high_rated = product_avg[product_avg >= 4]

# 🖨️ 8. Принтиране на резултатите
print("\n📊 Средна оценка по продукт:")
print(product_avg)

print("\n🙋‍♂️ Активност на потребителите:")
print(user_activity)

print("\n⭐ Продукти с рейтинг ≥ 4:")
print(high_rated)
