import pandas as pd

# Зареждане на CSV с правилен разделител
df = pd.read_csv("user_ratings.csv", sep=";", encoding="utf-8")

# Анализ 1: Средна оценка по продукт
product_avg = df.groupby("Product_ID")["Rating"].mean().sort_values(ascending=False)

# Анализ 2: Активност на потребители
user_activity = df["User_ID"].value_counts()

# Анализ 3: Продукти с рейтинг ≥ 4
top_rated = df[df["Rating"] >= 4]

# Анализ 4: User-Product рейтинг матрица
rating_matrix = df.pivot_table(index="User_ID", columns="Product_ID", values="Rating")

# Записване във Excel файл
with pd.ExcelWriter("user_analysis.xlsx") as writer:
    product_avg.to_frame(name="Average_Rating").to_excel(writer, sheet_name="Среден рейтинг по продукт")
    user_activity.to_frame(name="Ratings_Count").to_excel(writer, sheet_name="Активност на потребители")
    top_rated.to_excel(writer, sheet_name="Продукти с рейтинг ≥4", index=False)
    rating_matrix.to_excel(writer, sheet_name="Рейтинг матрица")

